from tkinter import *

win = Tk()
win.geometry('600x600')
win.title("КВАДРАТНЫЙ ШРЕКУС АСАСИН КРИДС ЗЕЛЁНЫЙ ТРОЛЛЬ БЕСПЛАТНО С БЮДЖЕТОМ  ТУЛЬСКИХ ПРЯНИКА")

canvas = Canvas(win,height=600,width=600,bg="blue")
canvas.pack()

class Priroda_i_shreck:
    def __init__(self,color1,color2,color3,color4,color5,color6,color7,color8):
        self.grass = color1
        self.sun = color2
        self.face_shreck = color3       #фейсе
        self.socks_shreck = color4
        self.hands_shreck = color5
        self.ears_shreck = color6      #око
        self.nose_shreck = color3
        self.body_shreck = color6       #тело
        self.pupil_shreck = color4      #зрачки
        self.guchi_shreck = color8
        self.eyes_shreck = color3
        self.prazdnik_shreck = color8

    def build_grass(self):
        canvas.create_rectangle(0, 600, 600, 520, fill=self.grass)

    def build_sun(self):
        canvas.create_oval(30,30,120,120, fill=self.sun)

    def build_shreck(self):

        canvas.create_rectangle(330, 455, 220, 335, fill=self.body_shreck)                         #тело
        canvas.create_rectangle(300, 470, 240, 430, fill=self.guchi_shreck,outline="saddle brown")    #штаны
        canvas.create_rectangle(250, 510, 220, 430, fill=self.guchi_shreck,outline="saddle brown")
        canvas.create_rectangle(330, 510, 300, 430, fill=self.guchi_shreck,outline="saddle brown")
        #носки
        canvas.create_rectangle(250,530, 200, 510, fill=self.socks_shreck)
        canvas.create_rectangle(350,530, 300, 510, fill=self.socks_shreck)

        #ушыыыыыыыыыы
        canvas.create_rectangle(245,200, 235, 270, fill=self.eyes_shreck)
        canvas.create_rectangle(315, 200, 305, 270, fill=self.eyes_shreck)
        canvas.create_oval(251, 190, 226, 200, fill=self.eyes_shreck)
        canvas.create_oval(321, 190, 295, 200, fill=self.eyes_shreck)
        #Лицо
        canvas.create_rectangle(325, 335, 225, 245, fill=self.face_shreck)

        # ОКО
        canvas.create_oval(235, 250, 260, 275, fill=self.ears_shreck)
        canvas.create_oval(315, 250, 290, 275, fill=self.ears_shreck)

        # ЗРАЧКИ
        canvas.create_oval(243, 256, 253, 266, fill=self.pupil_shreck)      #ЗРАЧКИ
        canvas.create_oval(296, 256, 306, 266, fill=self.pupil_shreck)

        # тем чем дышат не помню чем но там кароче воздухом еще чтобы не умереть от запаха болота хотя болота там нет но мне было лень поэтому да
        canvas.create_rectangle(276, 270, 272, 300, fill=self.nose_shreck)

        #руки
        canvas.create_rectangle(220, 360, 190, 335, fill=self.body_shreck)
        canvas.create_rectangle(360, 360, 330, 335, fill=self.body_shreck)
        canvas.create_rectangle(220, 420, 190, 355, fill=self.face_shreck)
        canvas.create_rectangle(360, 420, 330, 355, fill=self.face_shreck)
        canvas.create_text(270,180,text="С днём шрека ура ура ура",font="Verdana100",fill=self.prazdnik_shreck)

good_shreck = Priroda_i_shreck("green", "yellow", "OliveDrab1", "black","sienna4","white","green",'saddle brown')
good_shreck.build_grass()
good_shreck.build_sun()
good_shreck.build_shreck()





















win.mainloop()