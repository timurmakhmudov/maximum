from django.urls import path
from .views import profile_view, register_view, login_view, logout_view

urlpatterns = [
    path('profile/', profile_view, name='profile'),
    #добавляем урл логина
    path('login/', login_view, name='login'),
    #добавляем урл регистрации
    path('register/', register_view, name='register'),
    #урл выхода пользователя
    path('logout/', logout_view, name='logout'),
]